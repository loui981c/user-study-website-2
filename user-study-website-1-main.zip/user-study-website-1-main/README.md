# user-study-website-baseline
Only make changes to main branch, then commit the changes.
Run these commands to deploy (we use a temp branch gh-pages for deploy)
git checkout main
git push origin --delete gh-pages
npm run deploy
